<?php require("templates/header.php");?>
		

            <div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">hmmmmm....</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4">Hier ist es noch leer</p>
               <p> <img src="style/leer.png" width="104" height="90" alt="leer.."></p>
    </div>
  </div>
			
<?php require("templates/footer.php");?>

	
























</html>