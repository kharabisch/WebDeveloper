
			
            <div class="card text-center">
  
  <div class="card-body">
    <h5 class="card-title"></h5>
    <p class="card-text">@Copyright nur als Test gedacht.</p>
    
  </div>
  <div class="card-footer text-muted">
    Coded by Amin
  </div>
</div>
		</div>
	</body>