<?php
    #Besucherzäler
    $handle= fopen("besucher.txt", "r"); 
    $besucherzahl= fgets( $handle);
    fclose($handle);

    $besucherzahl ++; ###$besucherzahl=$besucherzahl+1  genau auch $besucherzahl+=1
    $handle=fopen("besucher.txt","w");
    fwrite($handle,$besucherzahl);
    fclose($handle);



?>
<!DOCTYPE html>
<html>
	<head>
		<title>Test für Praktikum</title>
		<meta name='description' content='praktiseite'/>
		
		<meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS<link rel='stylesheet'type='text/css' href='style.css'/> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

		
	</head>
		
	<body>
	<!--	<div id='wrapper'>
			<header>

			</header>
			<nav>
				<ul>
					<li><a href="index.php">Start</a></li>
					<li><a href="content.php">Content</a></li>
					<li><a href="login.php">Login</a></li>
					<li><a href="geheim.php">Geheim</a></li>
				</ul>
			</nav>
-->
            <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #e3f2fd;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Kostprobe</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Home</a>
        </li>
               <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="content.php">Content</a>
        </li>
                <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="geheim.php">Geheim</a>
        </li>

      </ul>  <span class="navbar-text">
        <a class="nav-link" href="login.php">Login</a>
      </span>

    </div>
  </div>
</nav>
