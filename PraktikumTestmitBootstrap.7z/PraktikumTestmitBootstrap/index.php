<?php require("templates/header.php");?>
			<div id='content'>
				<h1>Es geht los</h1>
				<p>Hier ma eine kleine kostprobe</p><br>
                <p><img src="style/5059114.png" width="104" height="90" alt="Kostprobe..."></p>
				
			</div>
<?php require("templates/footer.php");?>			
	


	
























</html>