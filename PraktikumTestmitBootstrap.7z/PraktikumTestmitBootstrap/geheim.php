<?php 
	

	require("templates/loginsystem.php");
	require("templates/header.php");

		if(isteingeloggt())
		{
			echo('<div class="container">
            <div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">Zugang.</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4"> Hallo '.$_SESSION['namen'].'
            Du Bist auserwählt</h1> <br><img src="style/key-2114046_640.jpg" width="154" height="120" alt="key.."> </p>
    </div>
    </div>
  </div> ');
		}
		else
		{ echo('<div class="container"> <div class="px-4 py-5 my-5 text-center">
    <h1 class="display-5 fw-bold">Kein Zugang.</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4"> Diese Seite ist nur für eingeloggte Nutzer </p>
    </div> 
    </div> 
    </div>');
		}		
?>				
	
<?php 
	require("templates/footer.php");
?>			
	


	
























</html>