
<?php require("templates/header.php");?>
			<div id='content'>
				<h1>Kontakt</h1>
				<p>...Hier werden meine Kontakte angezeigt</p>
				<form action="auswertung.php" method="POST">
					<label>Name:</label>
					<input name="username" type="text" placeholder="Name"/><br/>
					<textarea name="message" placeholder="Bitte Text eingeben"></textarea><br/>
					<input name="messagesubmit" value="Nachricht senden" type="submit"/>
				</form>
				<footer></footer>
				<footer></footer>
				<footer></footer>
			</div>
<?php require("templates/footer.php");?>			
			
	
























</html>