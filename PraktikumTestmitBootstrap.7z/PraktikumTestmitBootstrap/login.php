<?php
	require("templates/verdb.php");
	require("templates/loginsystem.php");
	require("templates/header.php");
?>	
	<div id='content'>
<?php

			if(isset($_POST['submit']))
			{
				
				if (empty($_POST['email']) || empty($_POST['password']))
					{
					echo('Bitte alle Felder ausfüllen');
					}
				else
					{
					$erg =login($_POST['email'], $_POST['password']);
					echo('<p>' . $erg . '</p>');	
					}
			}
			else if(isset($_POST['logout']))
			{
				logout();
				echo('<p>Erfolgreich ausgeloggt</p>');
			}
			else if(isteingeloggt())
			{?>
			<p>
				<form action = 'login.php' method='POST'>
					<input type='submit' name='logout' value='ausloggen'/>
			</form>	
			</p>
<?php
			}
			else
			{

			

	
?>
			<div class="container col-xl-10 col-xxl-8 px-4 py-5">
    <div class="row align-items-center g-lg-5 py-5">
      <div class="col-lg-7 text-center text-lg-start">
        <h1 class="display-4 fw-bold lh-1 mb-3">Hallo</h1>
        <p class="col-lg-10 fs-4">Bitte Loggen Sie sich ein.</p>
      </div>
      <div class="col-md-10 mx-auto col-lg-5">
        <form class="p-4 p-md-5 border rounded-3 bg-light" action="login.php" method="post" >
          <div class="form-floating mb-3">
            <input type="email" class="form-control" id="floatingInput" name="email" placeholder="name@mail.de">
            <label for="floatingInput">Email Addresse</label>
          </div>
          <div class="form-floating mb-3">
            <input type="password" class="form-control" id="floatingPassword" name="password" placeholder="Passwort">
            <label for="floatingPassword">Passwort</label>
          </div>
         
          <button class="w-100 btn btn-lg btn-primary" name="submit" type="submit">Login</button>
          <hr class="my-4">
          <small class="text-muted"></small>
          <a class="btn btn-primary" href="register.php">Registrieren</a>
        </form>
      </div>
    </div>
  </div>
  -----------
			<!--	<h1>Login</h1>
				<p>Willkommen zu login. <br/> Sonst bitte <a href="register.php"><input type="Submit" name ="submit"  value="Registrieren"/></a></p>
			<form action="login.php" method="post" >
				<label>Email Adresse :</label>
				<input type="text" name ="email" /> <br/>
				<label>Password      :    </label>
				<input type="password" name ="password" /> <br/>
				<input type="submit" name ="submit"  /> <br/>

			</form>	

			-->
<?php 
	}
?>
		</div>
<?php	
	require("templates/footer.php");
?>			
	


	
























</html>