<?php require("templates/header.php");?>
			<div id='content'>
				<h1>hmmm....</h1>
				<p>Hier ist es noch leer</p>
               <p> <img src="style/leer.png" width="104" height="90" alt="leer.."></p>
				
			</div>
			
<?php require("templates/footer.php");?>

	
























</html>