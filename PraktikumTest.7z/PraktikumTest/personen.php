<?php require("templates/header.php");?>
			<div id='content'>
				<h1>Register</h1>
				<p>Hier können Sie sich registrieren. <br/> <img src="style/key-2114459_1280.png" width="84" height="35" alt="key"><br><a href="register.php"><input type="Submit" name ="submit"  value="SIGN UP"/></a></p>
<?php 
		require("templates/verdb.php");


?>

			</div>
<?php require("templates/footer.php");?>			
	


	
























</html>