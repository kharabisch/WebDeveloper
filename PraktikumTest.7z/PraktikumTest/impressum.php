<?php require("templates/header.php");?>
			<div id='content'>
				<h1>uuuups!!!!</h1>
				<p>...Hier wird noch was eingetragen</p>
				
			</div>
			
<?php require("templates/footer.php");?>

	
























</html>