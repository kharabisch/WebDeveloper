<?php 
	

	require("templates/loginsystem.php");
	require("templates/header.php");
?>
			<div id='content'>
				
<?php
		if(isteingeloggt())
		{
			echo('<p> <h1>Zugang</h1><br>
            <h1>
            Hallo '.$_SESSION['namen'].'
            Du Bist auserwählt</h1> <br><img src="style/key-2114046_640.jpg" width="154" height="120" alt="key.."> </p>');
		}
		else
		{
			echo('<h1>Kein Zugang</h1><br><p>Diese Seite ist nur für eingeloggte Nutzer</p>');
		}
				
				
				
?>				
			</div>
<?php 
	require("templates/footer.php");
?>			
	


	
























</html>